﻿using System.Web;
using System.Web.Optimization;

namespace $safeprojectname$
{
    public static class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles) {
            /*
            bundles.Add(new ScriptBundle("~/Scripts/fmd").Include(
                "//fmd-static.uga.edu/js/bootstrap.js")
                );

            bundles.Add(new StyleBundle("~/Content/css").Include(
                "//fmd-static.uga.edu/css/bootstrap.css",
                "//fmd-static.uga.edu/css/font-awesome.css",
                "//fmd-static.uga.edu/css/fmd.css")
                );
             * */
        }
    }
}